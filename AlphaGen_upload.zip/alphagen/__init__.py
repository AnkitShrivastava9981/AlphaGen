"""AlphaGen weekly data collector."""
